import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException, TimeoutException, ElementClickInterceptedException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import os

def twitter_login_and_tweet(username, password, tweet_text):
    # Set up Chrome options
    chrome_options = Options()
    chrome_options.add_argument("--start-maximized")
    # Uncomment the following line to run Chrome in headless mode
    # chrome_options.add_argument("--headless")

    # Use explicit chromedriver path
    chromedriver_path = r"C:\Users\hi tech\Desktop\twiter\chromedriver.exe"
    service = Service(chromedriver_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)

    try:
        driver.get("https://twitter.com/login")
        wait = WebDriverWait(driver, 20)

        # Wait for username input to be present and enter username
        print("Waiting for username input...")
        username_input = wait.until(EC.presence_of_element_located((By.NAME, "text")))
        username_input.send_keys(username)
        username_input.send_keys(Keys.RETURN)
        print("Username entered.")

        # Twitter may ask for additional identifier (phone/email) if needed
        time.sleep(2)
        try:
            additional_input = driver.find_element(By.NAME, "text")
            if additional_input.is_displayed():
                print("Additional identifier requested, entering username again...")
                additional_input.send_keys(username)
                additional_input.send_keys(Keys.RETURN)
                time.sleep(2)
        except NoSuchElementException:
            pass

        # Wait for password input to be present and enter password
        print("Waiting for password input...")
        password_input = wait.until(EC.presence_of_element_located((By.NAME, "password")))
        password_input.send_keys(password)
        password_input.send_keys(Keys.RETURN)
        print("Password entered.")

        # Wait for home page to load by checking for tweet box presence
        print("Waiting for tweet box...")

        # Wait for loading spinner to disappear if present
        try:
            wait.until(EC.invisibility_of_element_located((By.CSS_SELECTOR, "div[role='progressbar']")))
            print("Loading spinner disappeared.")
        except TimeoutException:
            print("Loading spinner did not disappear in time, continuing...")

        # Try multiple selectors for tweet box
        tweet_box = None
        selectors = [
            "div[aria-label='Tweet text']",
            "div[data-testid='tweetTextarea_0']",
            "textarea[aria-label=\"What's happening?\"]",
            "div[aria-label=\"Tweet text\"]"
        ]
        for selector in selectors:
            try:
                tweet_box = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, selector)))
                print(f"Found tweet box with selector: {selector}")
                tweet_box.click()
                break
            except Exception as e:
                print(f"Selector {selector} not found or not clickable: {e}")

        if tweet_box is None:
            print("Failed to find or click tweet box with all selectors.")
            driver.save_screenshot("tweet_box_error.png")
            raise Exception("Tweet box not found")

        time.sleep(1)

        # Log message before entering tweet
        print("Entering tweet text...")

        # Enter tweet text
        tweet_box.send_keys(tweet_text)
        time.sleep(1)

        # Wait for the Tweet button to be clickable
        print("Waiting for tweet button...")

        # Try multiple selectors for tweet button
        tweet_button = None
        tweet_button_selectors = [
          "/html/body/div[1]/div/div/div[2]/main/div/div/div/div/div/div[3]/div/div[2]/div[1]/div/div/div/div[2]/div[2]/div[2]/div/div/div/button"
        ]
        for selector in tweet_button_selectors:
            try:
                tweet_button = wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                print(f"Found tweet button with selector: {selector}")
                break
            except Exception as e:
                print(f"Selector {selector} not found or not clickable: {e}")

        if tweet_button is None:
            print("Failed to find tweet button with all selectors.")
            driver.save_screenshot("tweet_button_error.png")
            raise Exception("Tweet button not found")

        # Log message before clicking tweet
        print("Clicking tweet button using JavaScript...")

        # Ensure tweet button is scrolled into view, focus it, and click
        driver.execute_script("arguments[0].scrollIntoView(true);", tweet_button)
        driver.execute_script("arguments[0].focus();", tweet_button)

        # Use JavaScript to click after ensuring focus and visibility
        try:
            driver.execute_script("arguments[0].click();", tweet_button)
            print("Clicked tweet button.")
        except Exception as e:
            print("Failed to click tweet button:", e)
            driver.save_screenshot("tweet_button_click_error.png")
            raise

        # Confirm tweet
        time.sleep(3)  # Wait for client-side processing
        # Check confirmation of tweeting
        try:
            wait.until(EC.presence_of_element_located((By.XPATH, "//span[contains(text(),'Your Tweet was sent')]")))
            print("Tweet confirmation detected.")
        except TimeoutException:
            print("Tweet confirmation not detected.")

        # Wait a bit before closing
        time.sleep(5)

    except (NoSuchElementException, TimeoutException, ElementClickInterceptedException) as e:
        print("An error occurred during login or tweeting:", e)
        driver.save_screenshot("general_error.png")
    finally:
        driver.quit()

if __name__ == "__main__":
    # Replace these placeholders with your Twitter credentials and tweet message
    TWITTER_USERNAME = "your username"
    TWITTER_PASSWORD = "your password"
    TWEET_MESSAGE = "Hello, this is an automated tweet from my Twitter bot!"

    twitter_login_and_tweet(TWITTER_USERNAME, TWITTER_PASSWORD, TWEET_MESSAGE)



