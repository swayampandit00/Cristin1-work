# Advanced Virtual Try-On System

Industry-level AI virtual try-on supporting shirts, pants, jackets, coats and suits.

## Features
- React frontend
- FastAPI backend
- Pose estimation
- Human parsing
- GAN-ready (CP-VTON, ACGPN)
- Dockerized backend

## Run
Backend:
uvicorn app:app --reload

Frontend:
npm install && npm start
