CP-VTON integration placeholder
