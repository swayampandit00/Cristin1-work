import axios from "axios";
export const tryOn = async (formData)=>{
  const res = await axios.post("http://localhost:8000/api/tryon", formData);
  return res.data;
};
