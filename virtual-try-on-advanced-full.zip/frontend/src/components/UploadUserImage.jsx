export default function UploadUserImage({setUser}){
  return <input type="file" onChange={e=>setUser(e.target.files[0])}/>
}
