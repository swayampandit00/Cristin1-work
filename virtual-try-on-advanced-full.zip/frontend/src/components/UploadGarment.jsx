export default function UploadGarment({setGarment}){
  return <input type="file" onChange={e=>setGarment(e.target.files[0])}/>
}
