export default ({image}) => image ? <img src={image} width="300"/> : null;
