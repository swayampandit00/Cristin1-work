export default function CategorySelector({setCategory}){
  return (
    <select onChange={e=>setCategory(e.target.value)}>
      <option value="shirt">Shirt</option>
      <option value="tshirt">T-Shirt</option>
      <option value="pant">Pant</option>
      <option value="jacket">Jacket</option>
      <option value="coat">Coat</option>
      <option value="suit">Suit</option>
    </select>
  );
}
