import {useState} from "react";
import {tryOn} from "../services/api";
import UploadUserImage from "../components/UploadUserImage";
import UploadGarment from "../components/UploadGarment";
import CategorySelector from "../components/CategorySelector";
import TryOnPreview from "../components/TryOnPreview";
import Loader from "../components/Loader";

export default function Home(){
  const [user,setUser]=useState(null);
  const [garment,setGarment]=useState(null);
  const [category,setCategory]=useState("shirt");
  const [loading,setLoading]=useState(false);
  const [result,setResult]=useState(null);

  const submit = async ()=>{
    const f=new FormData();
    f.append("user_image",user);
    f.append("garment_image",garment);
    f.append("category",category);
    setLoading(true);
    const r=await tryOn(f);
    setResult("http://localhost:8000/"+r.result);
    setLoading(false);
  };

  return (
    <div>
      <UploadUserImage setUser={setUser}/>
      <UploadGarment setGarment={setGarment}/>
      <CategorySelector setCategory={setCategory}/>
      <button onClick={submit}>Try On</button>
      {loading && <Loader/>}
      <TryOnPreview image={result}/>
    </div>
  );
}
