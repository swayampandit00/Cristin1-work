from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from routes.tryon import router

app = FastAPI()
app.include_router(router, prefix="/api")
app.mount("/static", StaticFiles(directory="static"), name="static")
