import cv2
def blend(user_path, cloth, mask):
    user=cv2.imread(user_path)
    y,x=100,100
    if cloth is None: return user
    for i in range(min(cloth.shape[0],user.shape[0]-y)):
        for j in range(min(cloth.shape[1],user.shape[1]-x)):
            if cloth.shape[2]==4 and cloth[i,j,3]>0:
                user[y+i,x+j]=cloth[i,j][:3]
    return user
