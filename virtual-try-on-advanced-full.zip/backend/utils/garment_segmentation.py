import cv2
def segment_garment(p):
    return cv2.imread(p,cv2.IMREAD_UNCHANGED)
