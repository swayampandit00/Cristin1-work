import cv2, numpy as np
def human_parsing(p):
    img=cv2.imread(p)
    h,w,_=img.shape
    return np.ones((h,w),dtype=np.uint8)*255
