import cv2, mediapipe as mp
def extract_pose(p):
    img=cv2.imread(p)
    rgb=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    r=mp.solutions.pose.Pose().process(rgb)
    pts={}
    if r.pose_landmarks:
        for i,lm in enumerate(r.pose_landmarks.landmark):
            pts[i]=(lm.x,lm.y)
    return pts
