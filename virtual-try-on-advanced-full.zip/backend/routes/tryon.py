from fastapi import APIRouter, UploadFile, File, Form
import uuid, cv2, os
from utils.pose_estimation import extract_pose
from utils.human_parsing import human_parsing
from utils.garment_segmentation import segment_garment
from utils.image_blending import blend

router = APIRouter()
UPLOAD="static/uploads/"
RESULT="static/results/"

@router.post("/tryon")
async def tryon(user_image:UploadFile=File(...), garment_image:UploadFile=File(...), category:str=Form(...)):
    uid=str(uuid.uuid4())
    os.makedirs(UPLOAD,exist_ok=True)
    os.makedirs(RESULT,exist_ok=True)
    up=UPLOAD+uid+"_u.png"
    gp=UPLOAD+uid+"_g.png"
    rp=RESULT+uid+"_r.png"

    open(up,"wb").write(await user_image.read())
    open(gp,"wb").write(await garment_image.read())

    pose=extract_pose(up)
    mask=human_parsing(up)
    cloth=segment_garment(gp)
    final=blend(up,cloth,mask)
    cv2.imwrite(rp,final)
    return {"result":rp}
